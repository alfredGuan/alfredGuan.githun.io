module.exports = {
  mongodb: "mongodb://localhost:27017/blog",
  baiduAK:"yFKaMEQnAYc1hA0AKaNyHGd4HTQgTNvO",
  //mongodb: "mongodb://admin:f642sgf5et@localhost:27017/admin"//err psw! notice!!!!
};